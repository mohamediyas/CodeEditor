import "bulmaswatch/superhero/bulmaswatch.min.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import ReactDOM from "react-dom";
import CodeCell from "./components/codeCell";
import TextEditor from "./components/TextEditor";
import { store } from "./state";
import { Provider } from "react-redux";
import CellList from "./components/CellList";

// esbuild wasm
const App = () => {
  return (
    <Provider store={store}>
      <div>
        {/* <CodeCell /> */}
        {/* <TextEditor /> */}
        <CellList />
      </div>
    </Provider>
  );
};

ReactDOM.render(<App />, document.querySelector("#root"));
