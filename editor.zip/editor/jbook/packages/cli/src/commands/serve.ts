import { Command } from "commander";
import { serve } from "@imthiyasjsnote/local-api";
import path from "path";

const isProduction = process.env.NODE_ENV === "production";

export const serveCommand = new Command()
  .command("serve [filename]")
  .description("Open a file for editing")
  .option("-p,--port <number>", "port to run server on", "4005")
  .action(async (fileName = "notebook.js", options: { port: string }) => {
    try {
      const dir = path.join(process.cwd(), path.dirname(fileName));

      await serve(
        parseInt(options.port),
        path.basename(fileName),
        dir,
        !isProduction
      );
      console.log(
        `Opened ${fileName} to navigate to http://localhost:${options.port} `
      );
    } catch (error: any) {
      console.log(error.message);
    }
  });
